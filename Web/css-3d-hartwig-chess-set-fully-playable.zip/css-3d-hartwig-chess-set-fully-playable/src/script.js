/*                                       

I had some issues running the javascript directly into codepen,
I wrapped everything in one external js file.
The full code can be found here : https://github.com/juliangarnier/3D-Hartwig-chess-set

*/